Start the game by running tictac.java
The player gets to make their move first
The game will read the x coordinate of the move followed by the y coordinate
It will then make the players move and print out the result
After that it will make the AI's move and print the result