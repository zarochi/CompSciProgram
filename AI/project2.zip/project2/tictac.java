public class tictac
{
   public static void main(String[] args)
   {
      tictac t = new tictac();
      String[][] board = new String[][]{{" "," "," "},{" "," "," "},{" "," "," "}}; //creates the initial board
      game g = new game(board);
      g.printBoard();
      
   }
   
}