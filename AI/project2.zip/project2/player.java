import java.util.ArrayList;

public class player
{
   boolean isTurnPlayer=false;//tracks whether or not it is the player's turn
   ArrayList<Integer> possessions = new ArrayList<Integer>();//keeps track of what spaces each player possesses
   int player=-1;
   
   public player(int p) //numbers the player
   {
      player=p;
   }
   
   public int getNumber() //gets the player number
   {
      return player;
   }
   
   public void setTurn(boolean b)   //allows for setting of whether or not it is a players turn
   {
      isTurnPlayer=b;
   }
   
   public boolean isTurn() //returns whether or not it is this player's turn
   {
      return isTurnPlayer;
   }
   
   public void addPossession(int x, int y)//takes coordinates and adds them as a possession of this player
   {
      possessions.add(y*3+x);//puts the move in the array as a single integer
      /* in this model, the board is thought of as the following
      [0][1][2]
      [3][4][5]
      [6][7][8]
      */
   }
}